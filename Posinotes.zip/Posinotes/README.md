First,please make sure you have The Flutter SDK installed on your machine, along with and appropriate IDE or text editor with flutter plug-ins installed. Check https://flutter.dev/docs/get-started/install for more details

Clone the repository using git clone https://github.com/clintroymkt/Posinotes

Type flutter packages get   - this will make sure you get all the required packages

Make sure you have an emulator running in debug mode, type flutter devices to see any emulator devices or connected physical devices

flutter run  will launch application from the terminal. If using Visual Studio code pressing F5 or selecting the run option also works. The same applies for IntelliJ or Android Studio.


for this software development flutter is used because it is new, and trendy plus as developers who had never done mobile development before this was a good way to start. The IDE used is vs code community and version control is done by github. For the most part youtube videos were used in learning the dart language and flutter altogether, youtube has a wide community of developers all delivering there knowledge for free. The flutter Documentation is most helpful is explaining how flutter and the whole idea with everything in flutte being a widget. Building the code was challenging as transferring visualisation into code is always unpleasant but with the skills we managed to acquired this repository is what we have so far.

Version control
Ide vs code, version control was handled in the terminal of vs code.
the repository was created and initialised on the gitub website.
after cloning as outlined above,
run "git init" to initialise the repository"
after successful edits, run "git pull"
to fully be up to date and download anychanges that might be done on the repository
run "git add ." Do no leave out that fullstop there and notice the space between add and the fullstop. This will make all your changes final and ready for uploading
run "git commit -m "commet here" this will again make all changes final and also add a comment to evry file you edited and new ones you commit, can be used to communicat to team members as to what happened where.
run "git push", the terminal will ask you for your github username and password, it will not show you your password as type it in though hit enter after entering username and then enter again after password.
git will work its magic and if successful, your changes have been commited to the master.
The reason for using github and git is because its the version control tool all team members are familiar with and also its simple to understand and use.
